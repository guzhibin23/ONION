clear;
clc
folder_now = pwd;
addpath([folder_now, '/funs']);
addpath([folder_now, '/Datasets/']);
clear;
clc
folder_now = pwd;
addpath([folder_now, '/funs']);
addpath([folder_now, '/Datasets/']);



dataname=["MSRCv1"];%"BBCSport","HW","MSRCv1","ORL","100leaves","CCV"
ablation_para=["alpha"," eta","beta","gamma"];
for it_name = 1:length(dataname)
    load(strcat(dataname(it_name),'.mat'));
    if dataname(it_name)~="ORL"
        gt=truelabel{1};
        X=data;
    end
    cls_num=length(unique(gt));
    %ѡ��ÿ�����ݼ���Ӧ�����ų�����
    if  dataname(it_name)=="BBCSport"
       alpha=1; eta= 12;beta= 1;gamma=0.1;omega= [1 10];
    elseif dataname(it_name)=="HW"
        alpha=1; eta= 10;beta= 0.01;gamma=0.2;omega= [ 1 0.7 1 20 30 40];
    elseif dataname(it_name)=="MSRCv1"
        alpha=0.9; eta= 8;beta= 0.001;gamma=0.5;omega= [ 0.9 1 1 1 1];
    elseif dataname(it_name)=="ORL"
        alpha=1; eta= 10;beta= 0.01;gamma=1.1;omega= [0.9 1 1];
    elseif dataname(it_name)=="100leaves"
        alpha=10; eta= 9;beta= 0.02;gamma=0.4;omega=[0.9 1 1];
    elseif dataname(it_name)=="CCV"
         alpha=0.5; eta= 30;beta= 0.01;gamma=1;omega= [0.9 1 1];
    end

        for j = 1:3
            [C_hat,Z,C,converge_C] = NOODLE(X, alpha,beta,gamma,eta,omega,gt);%X��a cell array, 1*view_num, each array is d_v*n
            C_hat=sparse(C_hat);
            Predicted = SpectralClustering(C_hat, cls_num);
            score(j,:) =  ClusteringMeasure(gt, Predicted)
        end
        re_mean = mean(score);
        re_std = std(score);
        save('result_'+dataname(it_name),'re_mean','re_std')
    end
% end



