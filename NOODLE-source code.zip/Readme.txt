
Run demo.m to get the results.

The tunable parameters about different datasets are listed as follows:
1.MSRCv1                alpha=0.9;eta= 8;beta= 0.001;gamma=0.5;omega= [ 0.9 1 1 1 1];
2.HW                    alpha=1;eta= 10;beta= 0.01;gamma=0.2;omega= [ 1 0.7 1 20 30 40];
3.BBCSport              alpha=1;eta= 12;beta= 1;gamma=0.1;omega= [1 10];
4.100leaves             alpha=10;eta= 9;beta= 0.02;gamma=0.4;omega=[0.9 1 1];
5.ORL                   alpha=1;eta= 10;beta= 0.01;gamma=1.1;omega= [0.9 1 1];
6.CCV                   alpha=0.5;eta= 30;beta= 0.01;gamma=1;omega= [0.9 1 1];


